package xyz;

public class Mahasiswa extends Orang{
	
	public Mahasiswa(String name, String address, String phone, String email, int year) {
		super(name, address, phone, email);
		this.year = year;
	}

	private int year;
	
	public int getYear() {
		return year;
	}

	public void setYear(int year) {
		this.year = year;
	}
	
	
}
