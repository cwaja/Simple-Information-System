package xyz;

public abstract class Karyawan extends Orang{
	public Karyawan(String name, String address, String phone, String email, String location, String date, int salary) {
		super(name, address, phone, email);
		this.location = location;
		this.date = date;
		this.salary = salary;
	}
	private String location, date;
	private int salary;
	
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public int getSalary() {
		return salary;
	}
	public void setSalary(int salary) {
		this.salary = salary;
	}
}
