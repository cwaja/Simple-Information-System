package xyz;

public class Administrator extends Karyawan{
	private	String title;

	public Administrator(String name, String address, String phone, String email, String location, String date, int salary, String title) {
		super(name, address, phone, email, location, date, salary);
		this.title = title;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}
	
}
