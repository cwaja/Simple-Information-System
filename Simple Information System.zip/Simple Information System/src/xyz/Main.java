package xyz;

import java.util.ArrayList;
import java.util.*;
import java.util.Scanner;

public class Main {
	Scanner scan = new Scanner(System.in);
	ArrayList<Mahasiswa> arraym = new ArrayList<Mahasiswa>();
	ArrayList<Dosen> arrayd = new ArrayList<Dosen>();
	ArrayList<Administrator> arraya = new ArrayList<Administrator>();
	int menu;
	Main(){
		do {
			System.out.println("XYZ Information System");
			System.out.println("Login as :");
			System.out.println("1. Mahasiswa");
			System.out.println("2. Dosen");
			System.out.println("3. Administrator");
			System.out.println("4. Logout");
			System.out.print(">> ");
			menu = scan.nextInt();
			scan.nextLine();
			switch(menu) {
			case 1: mahasiswa(); break;
			case 2: dosen(); break;
			case 3: admin(); break;
			}
		}while(menu!=4);
		
		
	}
	
	void mahasiswa() {
		int choice;
		int flag=0;
		String loginname;
		if(arraym.isEmpty()) {
			System.out.print("Must login as Administrator first");
			scan.nextLine();
			System.out.println();
		}else {
		do {
			System.out.print("Input Your Name : ");
			loginname = scan.nextLine();
			for(Mahasiswa list : arraym) {
				if(list.getName().equals(loginname)) {
					flag=1;
					break;
				}
			}
		}while(flag==0);
		do {
			System.out.println("MAHASISWA");
			System.out.println("1. Profile");
			System.out.println("2. Change Address");
			System.out.println("3. Change Phone Number");
			System.out.println("4. Change Email");
			System.out.println("5. Change User");
			System.out.print(">> ");
			choice = scan.nextInt();
			scan.nextLine();
			if(choice==1) {
				for(Mahasiswa list : arraym) {
					if(list.getName().equals(loginname)) {
						System.out.println("Name: " + list.getName());
						System.out.println("Address: " +list.getAddress());
						System.out.println("Phone: " + list.getPhone());
						System.out.println("Email: " + list.getEmail());
						System.out.println("Year of Study: "+ list.getYear());
						System.out.println();
						break;
					}
				}
			}else if(choice==2) {
				String address;
				System.out.print("Change your address to : ");
				address = scan.nextLine();
				for(Mahasiswa list : arraym) {
					if(list.getName().equals(loginname)) {
						list.setAddress(address);
						break;
					}
				}
			}else if(choice==3) {
				String phone;
				System.out.print("Change your phone number to : ");
				phone = scan.nextLine();
				for(Mahasiswa list : arraym) {
					if(list.getName().equals(loginname)) {
						list.setPhone(phone);
						break;
					}
				}
			}else if(choice==4) {
				String email;
				System.out.print("Change your email to : ");
				email = scan.nextLine();
				for(Mahasiswa list : arraym) {
					if(list.getName().equals(loginname)) {
						list.setEmail(email);
						break;
					}
				}
			}
		}while(choice!=5);
		}
	}
	
	void dosen() {
		int choice;
		int flag=0;
		String loginname;
		if(arrayd.isEmpty()) {
			System.out.print("Must login as Administrator first");
			scan.nextLine();
		}else {
		do {
			System.out.print("Input Your Name : ");
			loginname = scan.nextLine();
			for(Dosen list : arrayd) {
				if(list.getName().equals(loginname)) {
					flag=1;
					break;
				}
			}
		}while(flag==0);
		do {
			System.out.println("DOSEN");
			System.out.println("1. Profile");
			System.out.println("2. Change Address");
			System.out.println("3. Change Phone Number");
			System.out.println("4. Change Email");
			System.out.println("5. Change User");
			System.out.print(">> ");
			choice = scan.nextInt();
			scan.nextLine();
			if(choice==1) {
				for(Dosen list : arrayd) {
					if(list.getName().equals(loginname)) {
						System.out.println("Name: " + list.getName());
						System.out.println("Address: " +list.getAddress());
						System.out.println("Phone: " + list.getPhone());
						System.out.println("Email: " + list.getEmail());
						System.out.println("Office Location: " + list.getLocation());
						System.out.println("Date of Start: " + list.getDate());
						System.out.println("Salary: " + list.getSalary());
						System.out.println("Teach Hours: " + list.getTeachhours());
						System.out.println("Academic Level: " + list.getLevel());
						System.out.println();
						break;
					}
				}
			}else if(choice==2) {
				String address;
				System.out.print("Change your address to : ");
				address = scan.nextLine();
				for(Dosen list : arrayd) {
					if(list.getName().equals(loginname)) {
						list.setAddress(address);
						break;
					}
				}
			}else if(choice==3) {
				String phone;
				System.out.print("Change your phone number to : ");
				phone = scan.nextLine();
				for(Dosen list : arrayd) {
					if(list.getName().equals(loginname)) {
						list.setPhone(phone);
						break;
					}
				}
			}else if(choice==4) {
				String email;
				System.out.println("Change your email to : ");
				email = scan.nextLine();
				for(Dosen list : arrayd) {
					if(list.getName().equals(loginname)) {
						list.setEmail(email);
						break;
					}
				}
			}
		}while(choice!=5);
		}
	}
	
	void admin() {
		int choice, year, teachhours, salary;
		String name, phone, address, email, level, location, title, date;
		String loginname;
		if(arraya.isEmpty()) {
			System.out.print("Input Your Name: ");
			loginname = scan.nextLine();
			System.out.print("Input Your Address: ");
			address = scan.nextLine();
			System.out.print("Input Your Phone Number: ");
			phone = scan.nextLine();
			System.out.print("Input Your Email Address: ");
			email = scan.nextLine();
			do {
				System.out.print("Input Your Office Location[Kemanggisan|Alam Sutra|Bekasi|Bandung|Malang]: ");
				location = scan.nextLine();
			}while(!location.contains("Kemanggisan") && !location.contains("Alam Sutra") && !location.contains("Bekasi") && !location.contains("Bandung") && !location.contains("Malang"));
			Date date1 = new Date();
			date = date1.toString();
			System.out.print("Input Your Salary: ");
			salary = scan.nextInt();
			scan.nextLine();
			do {
				System.out.print("Input Your Title[Asisten Ahli|Lektor|Lektor Kepala|Professor]: ");
				title = scan.nextLine();	
			}while(!title.contains("Asisten Ahli") && !title.contains("Lektor") && !title.contains("Lektor Kepala") &&!title.contains("Professor"));
			arraya.add(new Administrator(loginname, address, phone, email, location, date, salary, title));
		}else {
			int flag=0;
			do {
				System.out.print("Input Your Name : ");
				loginname = scan.nextLine();
				for(Administrator list : arraya) {
					if(list.getName().equals(loginname)) {
						flag=1;
						break;
					}
				}
			}while(flag==0);
		}
		do {
			System.out.println("ADMINISTRATOR");
			System.out.println("1. Profile");
			System.out.println("2. Add Mahasiswa");
			System.out.println("3. Add Dosen");
			System.out.println("4. Add Administrator");
			System.out.println("5. List All Mahasiswa");
			System.out.println("6. List All Dosen");
			System.out.println("7. List All Administrator");
			System.out.println("8. List All User");
			System.out.println("9. Change User");
			System.out.print(">> ");
			choice = scan.nextInt();
			scan.nextLine();
			if(choice==1) {
				for(Administrator list : arraya) {
					if(list.getName().equals(loginname)) {
						System.out.println("Name: " + list.getName());
						System.out.println("Address: " +list.getAddress());
						System.out.println("Phone: " + list.getPhone());
						System.out.println("Email: " + list.getEmail());
						System.out.println("Location: " + list.getLocation());
						System.out.println("Date of Start: " + list.getDate());
						System.out.println("Salary: " + list.getSalary());
						System.out.println("Title: " + list.getTitle());
						System.out.println();
						break;
					}
				}
			}else if(choice==2) {
				System.out.print("Name : ");
				name = scan.nextLine();
				System.out.print("Address: ");
				address = scan.nextLine();
				do {
						try {
						System.out.print("Phone Number: ");
						phone = scan.nextLine();
					}catch(Exception e) {
						phone="";
					}
				}while(phone=="");
				System.out.print("E-mail Address: ");
				email = scan.nextLine();
				do {
					System.out.print("Year: ");
					year = scan.nextInt();
				}while(year<2015 || year>2020);
				arraym.add(new Mahasiswa(name, address, phone, email, year));
			}else if(choice==3) {
				System.out.print("Name : ");
				name = scan.nextLine();
				System.out.print("Address: ");
				address = scan.nextLine();
				do {
						try {
						System.out.print("Phone Number: ");
						phone = scan.nextLine();
					}catch(Exception e) {
						phone="";
					}
				}while(phone=="");
				System.out.print("E-mail Address: ");
				email = scan.nextLine();
				do {
					System.out.print("Location[Kemanggisan|Alam Sutra|Bekasi|Bandung|Malang]: ");
					location = scan.nextLine();
				}while(!location.contains("Kemanggisan") && !location.contains("Alam Sutra") && !location.contains("Bekasi") && !location.contains("Bandung") && !location.contains("Malang"));
				Date date1 = new Date();
				date = date1.toString();
				System.out.print("Salary: ");
				salary = scan.nextInt();
				System.out.print("Teaching Hours: ");
				teachhours = scan.nextInt();
				scan.nextLine();
				System.out.print("Academic Level: ");
				level = scan.nextLine();
				arrayd.add(new Dosen(name, address, phone, email, location, date, salary, teachhours, level));
			}else if(choice==4) {
				System.out.print("Name : ");
				name = scan.nextLine();
				System.out.print("Address: ");
				address = scan.nextLine();
				do {
						try {
						System.out.print("Phone Number: ");
						phone = scan.nextLine();
					}catch(Exception e) {
						phone="";
					}
				}while(phone=="");
				System.out.print("E-mail Address: ");
				email = scan.nextLine();
				do {
					System.out.print("Location[Kemanggisan|Alam Sutra|Bekasi|Bandung|Malang]: ");
					location = scan.nextLine();
				}while(!location.contains("Kemanggisan") && !location.contains("Alam Sutra") && !location.contains("Bekasi") && !location.contains("Bandung") && !location.contains("Malang"));
				Date date1 = new Date();
				date = date1.toString();
				System.out.print("Salary: ");
				salary = scan.nextInt();
				do {	
				System.out.print("Title[Staff|Supervisor|Manager|Kepala Divisi|Direksi]: ");
				title = scan.nextLine();
				}while(!title.contains("Staff") && !title.contains("Supervisor") && !title.contains("Manager") && !title.contains("Kepala Divisi") && !title.contains("Direksi"));
				arraya.add(new Administrator(name, address, phone, email, location, date, salary, title));
			}else if(choice==5) {
				System.out.println("MAHASISWA");
				for(Mahasiswa list : arraym) {
					System.out.println("Name          : " + list.getName());
					System.out.println("Year of Study : " + list.getYear());
				}
			}else if(choice==6) {
				System.out.println("DOSEN");
				for(Dosen list : arrayd) {
					System.out.println("Name            : " + list.getName());
					System.out.println("Office Location : " + list.getLocation());
					System.out.println("Academic  Level : " + list.getLevel());
					System.out.println();
				}
			}else if(choice==7) {
				System.out.println("ADMINISTRATOR");
				for(Administrator list : arraya) {
					System.out.println("Name            : " + list.getName());
					System.out.println("Office Location : " + list.getLocation());
					System.out.println("Title           : " + list.getTitle());
				}
			}else if(choice==8) {
				
			}
		}while(choice!=9);
	}
	public static void main(String[] args) {
		new Main();

	}

}
