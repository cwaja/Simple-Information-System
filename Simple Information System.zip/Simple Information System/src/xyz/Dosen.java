package xyz;

public class Dosen extends Karyawan{
	public Dosen(String name, String address, String phone, String email, String location, String date, int salary,
			int teachhours, String level) {
		super(name, address, phone, email, location, date, salary);
		this.teachhours = teachhours;
		this.level = level;
	}
	private int teachhours;
	private String level;
	
	public int getTeachhours() {
		return teachhours;
	}
	public void setTeachhours(int teachhours) {
		this.teachhours = teachhours;
	}
	public String getLevel() {
		return level;
	}
	public void setLevel(String level) {
		this.level = level;
	}
	
}
